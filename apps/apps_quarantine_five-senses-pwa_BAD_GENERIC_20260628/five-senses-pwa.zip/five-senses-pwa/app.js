const APP_CACHE_PREFIX = "five-senses";
const CACHE_MESSAGE_KEY = "five-senses-cache-message";

function toggleSense(btn) {
  const card = btn.closest(".sense-card");
  const isOpen = card.classList.contains("open");

  document.querySelectorAll(".sense-card").forEach((item) => item.classList.remove("open"));
  document.querySelectorAll(".sense-toggle").forEach((item) => item.setAttribute("aria-expanded", "false"));

  if (!isOpen) {
    card.classList.add("open");
    btn.setAttribute("aria-expanded", "true");
    setTimeout(() => card.scrollIntoView({ behavior: "smooth", block: "nearest" }), 50);
  }
}

function showCacheMessage(message) {
  const el = document.getElementById("cacheMessage");
  if (!el) return;
  el.textContent = message;
  el.hidden = false;
  localStorage.setItem(CACHE_MESSAGE_KEY, message);
}

function restoreCacheMessage() {
  const saved = localStorage.getItem(CACHE_MESSAGE_KEY);
  if (saved) showCacheMessage(saved);
}

function setupClearCache() {
  const btn = document.getElementById("clearCacheBtn");
  if (!btn) return;
  btn.addEventListener("click", async () => {
    try {
      if ("caches" in window) {
        const keys = await caches.keys();
        await Promise.all(keys.filter((key) => key.startsWith(APP_CACHE_PREFIX)).map((key) => caches.delete(key)));
      }
      if ("serviceWorker" in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        await Promise.all(registrations.map((registration) => registration.update()));
      }
      showCacheMessage("Cache cleared. Close and reopen this app to load the newest version.");
    } catch (error) {
      showCacheMessage("Cache clear attempted. If the app still looks old, close and reopen it while online.");
    }
  });
}

function setupTroubleshooting() {
  const btn = document.getElementById("troubleBtn");
  const panel = document.getElementById("troubleshootingPanel");
  const close = document.getElementById("closeTroubleBtn");
  if (!btn || !panel) return;

  const setOpen = (open) => {
    panel.hidden = !open;
    btn.setAttribute("aria-expanded", String(open));
  };

  btn.addEventListener("click", () => setOpen(panel.hidden));
  if (close) close.addEventListener("click", () => setOpen(false));
}

function registerServiceWorker() {
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("sw.js").catch(() => {});
  }
}

document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll('[data-action="toggle-sense"]').forEach((btn) => {
    btn.addEventListener("click", () => toggleSense(btn));
  });
  restoreCacheMessage();
  setupClearCache();
  setupTroubleshooting();
  registerServiceWorker();
});
