Five Senses PWA Dropdown App

Upload this folder as:
apps/five-senses/

Required hub link:
apps/five-senses/index.html

Suggested category:
Concepts or Volunteer Tools / Interpretation Skills

Files included:
index.html, styles.css, app.js, data.js, manifest.json, sw.js, icon.svg
