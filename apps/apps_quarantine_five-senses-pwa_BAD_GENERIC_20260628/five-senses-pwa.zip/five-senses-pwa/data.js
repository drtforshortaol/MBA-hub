/* Five Senses app content is currently embedded in index.html. Reserved for future hub registry/tag data updates. */
